extern int test (int);

int
test (int a)
{
  return a + a;
}
